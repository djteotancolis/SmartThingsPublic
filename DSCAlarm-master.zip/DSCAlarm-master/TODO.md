# Smartthings DSC Alarm Integration TODO

* Automate OAuth integration
* Send IP of alarmserver to ST and store in state variables so that it doesn't have to be setup in the config page of DSC Integration app anymore.
